<h2>Search For Patient</h2>
<form action="" method="post">
  Owner Name: <input id="name" name="name"><br>
  Dog Name: <input id="dog" name="dog"><br>
  <br>
  <button type="button" onclick="search()">Search</button>
</form>
