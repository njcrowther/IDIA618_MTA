<h1>Bibliography</h1>
<ul>
  <li><a href="https://www.w3schools.com/php/php_includes.asp">PHP Include</a></li>
  <li><a href="https://www.w3schools.com/bootstrap4/bootstrap_ref_js_tab.asp">Bootstrap Tabs</a></li>
  <li><a href="https://www.w3schools.com/sql/sql_where.asp">SQL Where</a></li>
  <li><a href="https://stackoverflow.com/questions/383631/json-encode-mysql-results">Encode MySQL Results</a></li>
  <li><a href="https://www.w3schools.com/js/js_json_parse.asp">JSON Parse</a></li>
</ul>
